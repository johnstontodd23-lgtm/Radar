# StormShieldAL — Setup

Live NWS radar, tornado and severe thunderstorm warning polygons, and GPS
tracking for North Alabama / Tennessee Valley. Native iOS (SwiftUI).

## Requirements
- A Mac with Xcode installed (free, Mac App Store)
- An iPhone with a cable (or on the same Wi-Fi for wireless install)
- A free Apple ID

## Steps
1. Open Xcode → Create New Project → iOS → App.
   - Product Name: StormShieldAL
   - Interface: SwiftUI, Language: Swift
2. In Finder, drag every .swift file from this folder into the Xcode project
   navigator (check "Copy items if needed"). Keep the Views/Models/Services
   groups if you like — Xcode doesn't care about folders, only membership.
   Delete the auto-generated ContentView.swift first so it doesn't clash.
3. Select the project → Signing & Capabilities → set Team to your Apple ID
   (Add Account if it's not there).
4. Select the project → Info tab → add these keys (or merge Info.plist):
   - "Privacy - Location When In Use Usage Description" → any sentence
   - "Privacy - Location Always and When In Use Usage Description" → any sentence
5. Plug in your iPhone, pick it as the run target, press Run (▶).
6. First launch on-device: iPhone Settings → General → VPN & Device
   Management → trust your developer certificate.

## Notes
- With a free Apple ID the install expires after 7 days — just press Run
  again to re-sign. A $99/yr Apple Developer account removes that limit.
- NWS API requires no key. RainViewer radar requires no key.
- Home location defaults to the Chandler Circle area; change it in
  Settings → "Set Home to Current Location" while standing at home.
