import Foundation

struct CurrentConditions {
    let temperature: Int
    let temperatureUnit: String
    let shortForecast: String
    let windSpeed: String
    let windDirection: String
    let probabilityOfPrecip: Int?
    let asOf: Date
}

// MARK: - NWS API decoding

struct NWSPointResponse: Decodable {
    let properties: NWSPointProperties
}

struct NWSPointProperties: Decodable {
    let forecastHourly: String
}

struct NWSForecastResponse: Decodable {
    let properties: NWSForecastProperties
}

struct NWSForecastProperties: Decodable {
    let periods: [NWSForecastPeriod]
}

struct NWSForecastPeriod: Decodable {
    let temperature: Int
    let temperatureUnit: String
    let shortForecast: String
    let windSpeed: String
    let windDirection: String
    let probabilityOfPrecipitation: NWSProbability?
}

struct NWSProbability: Decodable {
    let value: Int?
}
