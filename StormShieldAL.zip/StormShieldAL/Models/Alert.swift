import Foundation
import SwiftUI
import CoreLocation

enum ThreatLevel: Int {
    case clear, watch, warning

    var color: Color {
        switch self {
        case .clear:   return Color(red: 0.23, green: 0.85, blue: 0.56)
        case .watch:   return Color(red: 1.00, green: 0.77, blue: 0.24)
        case .warning: return Color(red: 1.00, green: 0.18, blue: 0.33)
        }
    }
}

struct WXAlert: Identifiable {
    let id: String
    let event: String
    let areaDesc: String
    let headline: String?
    let details: String
    let instruction: String?
    let expires: Date?
    let polygons: [[CLLocationCoordinate2D]]

    var priority: Int {
        switch event {
        case "Tornado Warning": return 0
        case "Severe Thunderstorm Warning": return 1
        case "Tornado Watch": return 2
        case "Severe Thunderstorm Watch": return 3
        case "Flash Flood Warning": return 4
        default: return 5
        }
    }

    var color: Color {
        switch event {
        case "Tornado Warning": return Color(red: 1.00, green: 0.18, blue: 0.33)
        case "Tornado Watch": return Color(red: 1.00, green: 0.77, blue: 0.24)
        case "Severe Thunderstorm Warning": return Color(red: 1.00, green: 0.62, blue: 0.04)
        case "Severe Thunderstorm Watch": return Color(red: 1.00, green: 0.72, blue: 0.42)
        default:
            return event.contains("Flood")
                ? Color(red: 0.20, green: 0.78, blue: 0.35)
                : Color(white: 0.6)
        }
    }
}

// MARK: - NWS GeoJSON decoding

struct NWSAlertResponse: Decodable {
    let features: [NWSFeature]
}

struct NWSFeature: Decodable {
    let id: String
    let properties: NWSProperties
    let geometry: NWSGeometry?

    func toAlert() -> WXAlert {
        WXAlert(
            id: id,
            event: properties.event,
            areaDesc: properties.areaDesc ?? "",
            headline: properties.headline,
            details: properties.description ?? "",
            instruction: properties.instruction,
            expires: properties.expires,
            polygons: geometry?.polygonCoordinates() ?? []
        )
    }
}

struct NWSProperties: Decodable {
    let event: String
    let areaDesc: String?
    let headline: String?
    let description: String?
    let instruction: String?
    let expires: Date?
}

struct NWSGeometry: Decodable {
    let type: String
    let coordinates: GeoCoordinates

    enum GeoCoordinates {
        case polygon([[[Double]]])
        case multiPolygon([[[[Double]]]])
        case other
    }

    enum CodingKeys: String, CodingKey { case type, coordinates }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        type = try container.decode(String.self, forKey: .type)
        switch type {
        case "Polygon":
            coordinates = .polygon(try container.decode([[[Double]]].self, forKey: .coordinates))
        case "MultiPolygon":
            coordinates = .multiPolygon(try container.decode([[[[Double]]]].self, forKey: .coordinates))
        default:
            coordinates = .other
        }
    }

    /// Returns rings as arrays of coordinates (lon/lat order in GeoJSON).
    func polygonCoordinates() -> [[CLLocationCoordinate2D]] {
        func ring(_ pts: [[Double]]) -> [CLLocationCoordinate2D] {
            pts.compactMap { p in
                guard p.count >= 2 else { return nil }
                return CLLocationCoordinate2D(latitude: p[1], longitude: p[0])
            }
        }
        switch coordinates {
        case .polygon(let rings):
            return rings.isEmpty ? [] : [ring(rings[0])]
        case .multiPolygon(let polys):
            return polys.compactMap { $0.first.map(ring) }
        case .other:
            return []
        }
    }
}
