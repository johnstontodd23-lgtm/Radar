import Foundation
import CoreLocation

struct AppLocation {
    /// Default home location — Chandler Circle area, Huntsville, AL.
    /// Adjustable in Settings; stored in UserDefaults.
    static var home: CLLocationCoordinate2D {
        let lat = UserDefaults.standard.object(forKey: "homeLat") as? Double ?? 34.699
        let lon = UserDefaults.standard.object(forKey: "homeLon") as? Double ?? -86.556
        return CLLocationCoordinate2D(latitude: lat, longitude: lon)
    }

    static func setHome(_ coordinate: CLLocationCoordinate2D) {
        UserDefaults.standard.set(coordinate.latitude, forKey: "homeLat")
        UserDefaults.standard.set(coordinate.longitude, forKey: "homeLon")
    }

    /// Default map region: North Alabama / Tennessee Valley.
    static let defaultSpanDegrees: Double = 2.4
}
