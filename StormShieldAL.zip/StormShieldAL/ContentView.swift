import SwiftUI

struct ContentView: View {
    @EnvironmentObject var nwsService: NWSService
    @EnvironmentObject var weatherService: WeatherService
    @EnvironmentObject var locationManager: LocationManager
    @EnvironmentObject var radarService: RadarService

    var body: some View {
        VStack(spacing: 0) {
            StatusBanner()
            TabView {
                RadarView()
                    .tabItem { Label("Radar", systemImage: "cloud.bolt.rain.fill") }
                AlertsView()
                    .tabItem { Label("Alerts", systemImage: "exclamationmark.triangle.fill") }
                SettingsView()
                    .tabItem { Label("Settings", systemImage: "gearshape.fill") }
            }
            .tint(Color("AccentGreen", bundle: nil))
        }
        .background(Color.black)
        .task {
            locationManager.requestPermission()
            await refreshAll()
        }
        .onReceive(Timer.publish(every: 120, on: .main, in: .common).autoconnect()) { _ in
            Task { await refreshAll() }
        }
    }

    private func refreshAll() async {
        async let alerts: Void = nwsService.fetchAlerts()
        async let radar: Void = radarService.fetchFrames()
        _ = await (alerts, radar)
        if let loc = locationManager.location {
            await weatherService.fetchConditions(lat: loc.coordinate.latitude,
                                                 lon: loc.coordinate.longitude)
        } else {
            await weatherService.fetchConditions(lat: AppLocation.home.latitude,
                                                 lon: AppLocation.home.longitude)
        }
    }
}

struct StatusBanner: View {
    @EnvironmentObject var nwsService: NWSService
    @State private var pulse = false

    var body: some View {
        HStack(spacing: 10) {
            Circle()
                .fill(nwsService.threatLevel.color)
                .frame(width: 12, height: 12)
                .scaleEffect(pulse && nwsService.threatLevel == .warning ? 1.35 : 1.0)
                .shadow(color: nwsService.threatLevel.color, radius: 6)
            Text(nwsService.statusText.uppercased())
                .font(.system(.subheadline, design: .monospaced).weight(.bold))
                .foregroundColor(nwsService.threatLevel.color)
            Spacer()
            VStack(alignment: .trailing, spacing: 1) {
                Text("Huntsville / N. Alabama")
                Text(nwsService.lastUpdated.map { "Updated \($0.formatted(date: .omitted, time: .shortened))" } ?? "Loading…")
            }
            .font(.caption2)
            .foregroundColor(.secondary)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background(nwsService.threatLevel == .warning ? Color.red.opacity(0.15) : Color(white: 0.08))
        .onAppear {
            withAnimation(.easeInOut(duration: 0.6).repeatForever(autoreverses: true)) {
                pulse = true
            }
        }
    }
}
