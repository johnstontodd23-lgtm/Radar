import SwiftUI

@main
struct StormShieldALApp: App {
    @StateObject private var locationManager = LocationManager()
    @StateObject private var nwsService = NWSService()
    @StateObject private var weatherService = WeatherService()
    @StateObject private var radarService = RadarService()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(locationManager)
                .environmentObject(nwsService)
                .environmentObject(weatherService)
                .environmentObject(radarService)
                .preferredColorScheme(.dark)
        }
    }
}
