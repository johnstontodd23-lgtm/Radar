import Foundation
import Combine

struct RadarFrame: Identifiable, Equatable {
    let id: Int          // unix timestamp
    let urlTemplate: String

    var time: Date { Date(timeIntervalSince1970: TimeInterval(id)) }
}

@MainActor
final class RadarService: ObservableObject {
    @Published var frames: [RadarFrame] = []
    @Published var currentIndex: Int = 0
    @Published var isPlaying: Bool = false
    @Published var fetchError: String?

    private var playTimer: Timer?

    var currentFrame: RadarFrame? {
        guard frames.indices.contains(currentIndex) else { return nil }
        return frames[currentIndex]
    }

    func fetchFrames() async {
        guard let url = URL(string: "https://api.rainviewer.com/public/weather-maps.json") else { return }
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            guard
                let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                let host = json["host"] as? String,
                let radar = json["radar"] as? [String: Any],
                let past = radar["past"] as? [[String: Any]]
            else { return }

            var newFrames: [RadarFrame] = past.suffix(8).compactMap { entry in
                guard let time = entry["time"] as? Int, let path = entry["path"] as? String else { return nil }
                // color scheme 2, smoothing on, snow on
                return RadarFrame(id: time, urlTemplate: "\(host)\(path)/256/{z}/{x}/{y}/2/1_1.png")
            }
            if let nowcast = (radar["nowcast"] as? [[String: Any]])?.first,
               let time = nowcast["time"] as? Int, let path = nowcast["path"] as? String {
                newFrames.append(RadarFrame(id: time, urlTemplate: "\(host)\(path)/256/{z}/{x}/{y}/2/1_1.png"))
            }
            frames = newFrames
            currentIndex = max(0, newFrames.count - 1)
            fetchError = nil
        } catch {
            fetchError = error.localizedDescription
        }
    }

    func togglePlay() {
        isPlaying.toggle()
        playTimer?.invalidate()
        if isPlaying {
            playTimer = Timer.scheduledTimer(withTimeInterval: 0.55, repeats: true) { [weak self] _ in
                Task { @MainActor in
                    guard let self, !self.frames.isEmpty else { return }
                    self.currentIndex = (self.currentIndex + 1) % self.frames.count
                }
            }
        } else {
            currentIndex = max(0, frames.count - 1)
        }
    }
}
