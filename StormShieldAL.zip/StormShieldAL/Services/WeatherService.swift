import Foundation
import Combine

@MainActor
final class WeatherService: ObservableObject {
    @Published var conditions: CurrentConditions?
    @Published var fetchError: String?

    func fetchConditions(lat: Double, lon: Double) async {
        do {
            // Step 1: resolve the NWS grid for this point.
            let pointURL = URL(string: String(format: "https://api.weather.gov/points/%.4f,%.4f", lat, lon))!
            var pointReq = URLRequest(url: pointURL)
            pointReq.setValue("StormShieldAL/1.0 (personal use)", forHTTPHeaderField: "User-Agent")
            let (pointData, _) = try await URLSession.shared.data(for: pointReq)
            let point = try JSONDecoder().decode(NWSPointResponse.self, from: pointData)

            // Step 2: pull the hourly forecast; first period is current conditions.
            guard let forecastURL = URL(string: point.properties.forecastHourly) else { return }
            var fReq = URLRequest(url: forecastURL)
            fReq.setValue("StormShieldAL/1.0 (personal use)", forHTTPHeaderField: "User-Agent")
            let (fData, _) = try await URLSession.shared.data(for: fReq)
            let forecast = try JSONDecoder().decode(NWSForecastResponse.self, from: fData)

            if let now = forecast.properties.periods.first {
                conditions = CurrentConditions(
                    temperature: now.temperature,
                    temperatureUnit: now.temperatureUnit,
                    shortForecast: now.shortForecast,
                    windSpeed: now.windSpeed,
                    windDirection: now.windDirection,
                    probabilityOfPrecip: now.probabilityOfPrecipitation?.value,
                    asOf: Date()
                )
                fetchError = nil
            }
        } catch {
            fetchError = error.localizedDescription
        }
    }
}
