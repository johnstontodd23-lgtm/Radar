import Foundation
import Combine

@MainActor
final class NWSService: ObservableObject {
    @Published var alerts: [WXAlert] = []
    @Published var lastUpdated: Date?
    @Published var fetchError: String?

    private let trackedEvents: Set<String> = [
        "Tornado Warning", "Tornado Watch",
        "Severe Thunderstorm Warning", "Severe Thunderstorm Watch",
        "Flash Flood Warning", "Special Weather Statement"
    ]

    var threatLevel: ThreatLevel {
        if alerts.contains(where: { $0.event.hasSuffix("Warning") && ($0.event.contains("Tornado") || $0.event.contains("Thunderstorm")) }) {
            return .warning
        }
        if alerts.contains(where: { $0.event.hasSuffix("Watch") }) {
            return .watch
        }
        return .clear
    }

    var statusText: String {
        let torWarn = alerts.filter { $0.event == "Tornado Warning" }.count
        let svrWarn = alerts.filter { $0.event == "Severe Thunderstorm Warning" }.count
        let watches = alerts.filter { $0.event.hasSuffix("Watch") }.count
        if torWarn > 0 { return "Tornado Warning (\(torWarn))" }
        if svrWarn > 0 { return "Severe T-Storm Warning (\(svrWarn))" }
        if watches > 0 { return "Watch in Effect (\(watches))" }
        return fetchError == nil ? "All Clear" : "Data Unavailable"
    }

    func fetchAlerts() async {
        guard let url = URL(string: "https://api.weather.gov/alerts/active?area=AL,TN&status=actual&message_type=alert,update") else { return }
        var request = URLRequest(url: url)
        // NWS requires an identifying User-Agent.
        request.setValue("StormShieldAL/1.0 (personal use)", forHTTPHeaderField: "User-Agent")
        request.setValue("application/geo+json", forHTTPHeaderField: "Accept")

        do {
            let (data, _) = try await URLSession.shared.data(for: request)
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .custom { d in
                let container = try d.singleValueContainer()
                let str = try container.decode(String.self)
                let fmt = ISO8601DateFormatter()
                fmt.formatOptions = [.withInternetDateTime]
                if let date = fmt.date(from: str) { return date }
                fmt.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
                if let date = fmt.date(from: str) { return date }
                throw DecodingError.dataCorruptedError(in: container, debugDescription: "Bad date: \(str)")
            }
            let response = try decoder.decode(NWSAlertResponse.self, from: data)
            let filtered = response.features
                .map { $0.toAlert() }
                .filter { trackedEvents.contains($0.event) }
                .sorted { $0.priority < $1.priority }
            alerts = filtered
            lastUpdated = Date()
            fetchError = nil
        } catch {
            fetchError = error.localizedDescription
            // Keep previously loaded alerts so a brief signal drop doesn't blank the board.
        }
    }
}
