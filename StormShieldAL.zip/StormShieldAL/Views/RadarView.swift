import SwiftUI
import MapKit

struct RadarView: View {
    @EnvironmentObject var radarService: RadarService
    @EnvironmentObject var nwsService: NWSService
    @EnvironmentObject var locationManager: LocationManager
    @State private var followUser = false

    var body: some View {
        ZStack(alignment: .topTrailing) {
            RadarMapView(
                frame: radarService.currentFrame,
                alerts: nwsService.alerts,
                userLocation: locationManager.location,
                followUser: followUser
            )
            .ignoresSafeArea(edges: .bottom)

            VStack(spacing: 10) {
                ControlButton(icon: followUser ? "location.fill" : "location",
                              active: followUser) {
                    followUser.toggle()
                    if followUser { locationManager.startTracking() }
                }
                ControlButton(icon: radarService.isPlaying ? "pause.fill" : "play.fill",
                              active: radarService.isPlaying) {
                    radarService.togglePlay()
                }
                ControlButton(icon: "arrow.clockwise", active: false) {
                    Task {
                        await radarService.fetchFrames()
                        await nwsService.fetchAlerts()
                    }
                }
            }
            .padding(.trailing, 12)
            .padding(.top, 12)

            if let frame = radarService.currentFrame {
                Text("RADAR \(frame.time.formatted(date: .omitted, time: .shortened))")
                    .font(.system(.caption, design: .monospaced).weight(.semibold))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 8))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.leading, 12)
                    .padding(.top, 12)
            }
        }
    }
}

struct ControlButton: View {
    let icon: String
    let active: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: 18, weight: .semibold))
                .foregroundColor(active ? ThreatLevel.clear.color : .white)
                .frame(width: 46, height: 46)
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12))
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(active ? ThreatLevel.clear.color : .clear, lineWidth: 1)
                )
        }
    }
}

// MARK: - MKMapView wrapper (SwiftUI Map doesn't support tile overlays)

struct RadarMapView: UIViewRepresentable {
    let frame: RadarFrame?
    let alerts: [WXAlert]
    let userLocation: CLLocation?
    let followUser: Bool

    func makeUIView(context: Context) -> MKMapView {
        let map = MKMapView()
        map.delegate = context.coordinator
        map.showsUserLocation = true
        map.pointOfInterestFilter = .excludingAll
        map.overrideUserInterfaceStyle = .dark
        map.setRegion(MKCoordinateRegion(
            center: AppLocation.home,
            span: MKCoordinateSpan(latitudeDelta: AppLocation.defaultSpanDegrees,
                                   longitudeDelta: AppLocation.defaultSpanDegrees)
        ), animated: false)

        let home = MKPointAnnotation()
        home.coordinate = AppLocation.home
        home.title = "Home"
        map.addAnnotation(home)
        return map
    }

    func updateUIView(_ map: MKMapView, context: Context) {
        // Radar tile overlay: replace only when the frame changes.
        if context.coordinator.currentTemplate != frame?.urlTemplate {
            context.coordinator.currentTemplate = frame?.urlTemplate
            map.removeOverlays(map.overlays.filter { $0 is MKTileOverlay })
            if let template = frame?.urlTemplate {
                let overlay = MKTileOverlay(urlTemplate: template)
                overlay.canReplaceMapContent = false
                map.addOverlay(overlay, level: .aboveRoads)
            }
        }

        // Alert polygons: rebuild when the alert set changes.
        let alertIDs = alerts.map(\.id).joined()
        if context.coordinator.currentAlertIDs != alertIDs {
            context.coordinator.currentAlertIDs = alertIDs
            map.removeOverlays(map.overlays.filter { $0 is AlertPolygon })
            for alert in alerts {
                for ring in alert.polygons where ring.count > 2 {
                    let polygon = AlertPolygon(coordinates: ring, count: ring.count)
                    polygon.alertEvent = alert.event
                    map.addOverlay(polygon, level: .aboveRoads)
                }
            }
        }

        if followUser, let loc = userLocation {
            map.setCenter(loc.coordinate, animated: true)
        }
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    final class Coordinator: NSObject, MKMapViewDelegate {
        var currentTemplate: String?
        var currentAlertIDs: String = ""

        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            if let tile = overlay as? MKTileOverlay {
                let renderer = MKTileOverlayRenderer(tileOverlay: tile)
                renderer.alpha = 0.72
                return renderer
            }
            if let polygon = overlay as? AlertPolygon {
                let renderer = MKPolygonRenderer(polygon: polygon)
                let color = AlertPolygon.uiColor(for: polygon.alertEvent)
                renderer.strokeColor = color
                renderer.fillColor = color.withAlphaComponent(0.14)
                renderer.lineWidth = 2
                return renderer
            }
            return MKOverlayRenderer(overlay: overlay)
        }
    }
}

final class AlertPolygon: MKPolygon {
    var alertEvent: String = ""

    static func uiColor(for event: String) -> UIColor {
        switch event {
        case "Tornado Warning": return UIColor(red: 1.00, green: 0.18, blue: 0.33, alpha: 1)
        case "Tornado Watch": return UIColor(red: 1.00, green: 0.77, blue: 0.24, alpha: 1)
        case "Severe Thunderstorm Warning": return UIColor(red: 1.00, green: 0.62, blue: 0.04, alpha: 1)
        case "Severe Thunderstorm Watch": return UIColor(red: 1.00, green: 0.72, blue: 0.42, alpha: 1)
        default:
            return event.contains("Flood")
                ? UIColor(red: 0.20, green: 0.78, blue: 0.35, alpha: 1)
                : UIColor.gray
        }
    }
}
