import SwiftUI

struct WeatherCard: View {
    @EnvironmentObject var weatherService: WeatherService

    var body: some View {
        if let wx = weatherService.conditions {
            HStack(spacing: 16) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("\(wx.temperature)°\(wx.temperatureUnit)")
                        .font(.system(size: 40, weight: .bold, design: .rounded))
                    Text(wx.shortForecast)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 4) {
                    Label("\(wx.windDirection) \(wx.windSpeed)", systemImage: "wind")
                    if let pop = wx.probabilityOfPrecip {
                        Label("\(pop)%", systemImage: "drop.fill")
                    }
                    Text("As of \(wx.asOf.formatted(date: .omitted, time: .shortened))")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                }
                .font(.caption)
            }
            .padding(.vertical, 6)
        } else {
            HStack {
                ProgressView()
                Text("Loading conditions…")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            .padding(.vertical, 6)
        }
    }
}
