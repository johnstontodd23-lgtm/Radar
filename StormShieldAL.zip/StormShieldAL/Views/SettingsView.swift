import SwiftUI
import CoreLocation

struct SettingsView: View {
    @EnvironmentObject var locationManager: LocationManager
    @AppStorage("homeLat") private var homeLat: Double = 34.699
    @AppStorage("homeLon") private var homeLon: Double = -86.556
    @State private var showSetHomeConfirm = false

    var body: some View {
        NavigationStack {
            Form {
                Section("Home Location") {
                    LabeledContent("Latitude", value: String(format: "%.4f", homeLat))
                    LabeledContent("Longitude", value: String(format: "%.4f", homeLon))
                    Button("Set Home to Current Location") {
                        showSetHomeConfirm = true
                    }
                    .disabled(locationManager.location == nil)
                }
                .confirmationDialog("Set home to your current GPS position?",
                                    isPresented: $showSetHomeConfirm,
                                    titleVisibility: .visible) {
                    Button("Set Home") {
                        if let loc = locationManager.location {
                            homeLat = loc.coordinate.latitude
                            homeLon = loc.coordinate.longitude
                        }
                    }
                }

                Section("Location Access") {
                    LabeledContent("Status", value: statusDescription)
                    if locationManager.authorizationStatus == .denied {
                        Text("Location is off. Enable it in iPhone Settings → Privacy → Location Services → StormShieldAL.")
                            .font(.caption)
                            .foregroundColor(.orange)
                    }
                }

                Section("About") {
                    LabeledContent("Data Sources", value: "NWS, RainViewer")
                    LabeledContent("Coverage", value: "Alabama & Tennessee")
                    Text("Radar imagery lags real time by several minutes. This app is a situational awareness tool, not a substitute for official warnings. Keep Wireless Emergency Alerts on and carry a NOAA Weather Radio when chasing.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            .scrollContentBackground(.hidden)
            .background(Color.black)
            .navigationTitle("Settings")
        }
    }

    private var statusDescription: String {
        switch locationManager.authorizationStatus {
        case .authorizedAlways: return "Always"
        case .authorizedWhenInUse: return "While Using"
        case .denied: return "Denied"
        case .restricted: return "Restricted"
        default: return "Not Determined"
        }
    }
}
