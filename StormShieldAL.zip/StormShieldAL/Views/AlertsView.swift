import SwiftUI

struct AlertsView: View {
    @EnvironmentObject var nwsService: NWSService
    @EnvironmentObject var weatherService: WeatherService

    var body: some View {
        NavigationStack {
            List {
                Section {
                    WeatherCard()
                        .listRowBackground(Color(white: 0.1))
                }

                Section {
                    if nwsService.alerts.isEmpty {
                        Text(nwsService.fetchError == nil
                             ? "No active tornado, severe thunderstorm, or flood alerts in AL / TN."
                             : "Can't reach the National Weather Service. Showing last known data.\n(\(nwsService.fetchError ?? ""))")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                            .listRowBackground(Color(white: 0.1))
                    } else {
                        ForEach(nwsService.alerts) { alert in
                            AlertRow(alert: alert)
                                .listRowBackground(Color(white: 0.1))
                        }
                    }
                } header: {
                    Text("Active Alerts — AL / TN")
                } footer: {
                    Text("Data: National Weather Service, refreshed every 2 minutes. Never rely on this app alone for life-safety decisions — keep Wireless Emergency Alerts and NOAA Weather Radio on.")
                }
            }
            .scrollContentBackground(.hidden)
            .background(Color.black)
            .navigationTitle("Alerts")
            .refreshable { await nwsService.fetchAlerts() }
        }
    }
}

struct AlertRow: View {
    let alert: WXAlert
    @State private var expanded = false

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 8) {
                RoundedRectangle(cornerRadius: 2)
                    .fill(alert.color)
                    .frame(width: 4, height: 34)
                VStack(alignment: .leading, spacing: 2) {
                    Text(alert.event)
                        .font(.headline)
                        .foregroundColor(alert.color)
                    if let expires = alert.expires {
                        Text("Until \(expires.formatted(date: .omitted, time: .shortened))")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
                Spacer()
                Image(systemName: expanded ? "chevron.up" : "chevron.down")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            Text(alert.areaDesc)
                .font(.caption)
                .foregroundColor(.secondary)
                .lineLimit(expanded ? nil : 2)

            if expanded {
                Text(alert.details)
                    .font(.footnote)
                    .foregroundColor(.primary.opacity(0.85))
                if let instruction = alert.instruction, !instruction.isEmpty {
                    Text(instruction)
                        .font(.footnote.weight(.semibold))
                        .foregroundColor(alert.color)
                }
            }
        }
        .padding(.vertical, 4)
        .contentShape(Rectangle())
        .onTapGesture { withAnimation(.easeInOut(duration: 0.2)) { expanded.toggle() } }
    }
}
